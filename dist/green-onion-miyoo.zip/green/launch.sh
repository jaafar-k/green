#!/bin/sh
mydir=`dirname "$0"`
midir="/mnt/SDCARD/App/parasyte/rootfs"

# HOME in app dir so ~/.green.pages and ~/.green.bookmarks persist here
export HOME=$mydir
export FONTCONFIG_PATH=$mydir/fonts
export FONTCONFIG_FILE=$mydir/conf/fonts.conf
export PATH=$mydir/bin:$midir/usr/local/sbin:$midir/usr/local/bin:$midir/usr/sbin:$midir/usr/bin:$midir/sbin:$midir/bin:$PATH
# App libs first; Parasyte rootfs remains as fallback for anything still missing
export LD_LIBRARY_PATH=$mydir/libs:$midir/lib:$midir/usr/lib:$LD_LIBRARY_PATH

cd $mydir
./green "$1"
