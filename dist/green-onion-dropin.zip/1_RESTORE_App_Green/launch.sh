#!/bin/sh
sysdir=/mnt/SDCARD/.tmp_update
mediadir=/mnt/SDCARD/Media/PDF
export HOME=/mnt/SDCARD/Saves/CurrentProfile/saves/green
mkdir -p "$HOME"
while :
do
	cd $sysdir
	./bin/st -q -e "$sysdir/script/file_selector.sh" "PDF Reader" "$mediadir" "pdf"
	retVal=$?
	echo "=================" "$retVal"
	if [ $retVal -eq 137 ] || [ ! -f "$mediadir/.selected.pls" ]; then
		exit
	fi
	selected_file=$(cat "$mediadir/.selected.pls")
	if [ ! -f "$selected_file" ]; then
		continue
	fi
	echo "$selected_file"
	LD_LIBRARY_PATH="$sysdir/lib/parasyte:$LD_LIBRARY_PATH" $sysdir/bin/green/green "$selected_file"
done
